from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import DallETool

@CrewBase
class AiPostGeneratorForConvertingIdeasIntoStructuredContentCrew():
    """AiPostGeneratorForConvertingIdeasIntoStructuredContent crew"""

    @agent
    def outline_architect(self) -> Agent:
        return Agent(
            config=self.agents_config['outline_architect'],
            tools=[],
        )

    @agent
    def content_expander(self) -> Agent:
        return Agent(
            config=self.agents_config['content_expander'],
            tools=[],
        )

    @agent
    def debate_analyst(self) -> Agent:
        return Agent(
            config=self.agents_config['debate_analyst'],
            tools=[],
        )

    @agent
    def creative_director(self) -> Agent:
        return Agent(
            config=self.agents_config['creative_director'],
            tools=[DallETool()],
        )

    @agent
    def content_reviewer(self) -> Agent:
        return Agent(
            config=self.agents_config['content_reviewer'],
            tools=[],
        )


    @task
    def create_outline(self) -> Task:
        return Task(
            config=self.tasks_config['create_outline'],
            tools=[],
        )

    @task
    def expand_content(self) -> Task:
        return Task(
            config=self.tasks_config['expand_content'],
            tools=[],
        )

    @task
    def generate_counterarguments(self) -> Task:
        return Task(
            config=self.tasks_config['generate_counterarguments'],
            tools=[],
        )

    @task
    def create_illustration_prompt(self) -> Task:
        return Task(
            config=self.tasks_config['create_illustration_prompt'],
            tools=[],
        )

    @task
    def generate_illustration(self) -> Task:
        return Task(
            config=self.tasks_config['generate_illustration'],
            tools=[DallETool()],
        )

    @task
    def final_review(self) -> Task:
        return Task(
            config=self.tasks_config['final_review'],
            tools=[],
        )


    @crew
    def crew(self) -> Crew:
        """Creates the AiPostGeneratorForConvertingIdeasIntoStructuredContent crew"""
        return Crew(
            agents=self.agents, # Automatically created by the @agent decorator
            tasks=self.tasks, # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )
