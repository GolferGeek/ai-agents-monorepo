from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import SeleniumScrapingTool

@CrewBase
class TwitterUserListManagerAndTweetAggregatorCrew():
    """TwitterUserListManagerAndTweetAggregator crew"""

    @agent
    def twitter_scraper(self) -> Agent:
        return Agent(
            config=self.agents_config['twitter_scraper'],
            tools=[SeleniumScrapingTool()],
        )

    @agent
    def content_formatter(self) -> Agent:
        return Agent(
            config=self.agents_config['content_formatter'],
            tools=[],
        )


    @task
    def collect_tweets(self) -> Task:
        return Task(
            config=self.tasks_config['collect_tweets'],
            tools=[SeleniumScrapingTool()],
        )

    @task
    def format_tweets(self) -> Task:
        return Task(
            config=self.tasks_config['format_tweets'],
            tools=[],
        )


    @crew
    def crew(self) -> Crew:
        """Creates the TwitterUserListManagerAndTweetAggregator crew"""
        return Crew(
            agents=self.agents, # Automatically created by the @agent decorator
            tasks=self.tasks, # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )
